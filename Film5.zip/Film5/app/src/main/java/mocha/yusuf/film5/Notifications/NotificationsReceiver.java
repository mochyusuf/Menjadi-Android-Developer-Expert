package mocha.yusuf.film5.Notifications;

public class NotificationsReceiver {
}
